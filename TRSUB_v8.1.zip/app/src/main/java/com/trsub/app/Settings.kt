package com.trsub.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** إعدادات التطبيق المحفوظة على الهاتف. */
class Settings(ctx: Context) {
    private val p: SharedPreferences = openPrefs(ctx)

    private fun openPrefs(ctx: Context): SharedPreferences {
        val plain = ctx.getSharedPreferences("trsub", Context.MODE_PRIVATE)
        return try {
            val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            val enc = EncryptedSharedPreferences.create(
                ctx, "trsub_secure", mk,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            val old = plain.all
            if (old.isNotEmpty()) {
                val e = enc.edit()
                for ((k, v) in old) {
                    when (v) {
                        is String -> e.putString(k, v)
                        is Boolean -> e.putBoolean(k, v)
                        is Float -> e.putFloat(k, v)
                        is Int -> e.putInt(k, v)
                        is Long -> e.putLong(k, v)
                    }
                }
                e.apply()
                plain.edit().clear().apply()
            }
            enc
        } catch (e: Exception) {
            plain
        }
    }

    var key: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v).apply() }

    var url: String
        get() = p.getString("url", DEFAULT_URL) ?: DEFAULT_URL
        set(v) { p.edit().putString("url", v).apply() }

    var whisperModel: String
        get() = p.getString("whisper", DEFAULT_WHISPER) ?: DEFAULT_WHISPER
        set(v) { p.edit().putString("whisper", v).apply() }

    var llmModel: String
        get() {
            val saved = p.getString("llm", null)
            // فقط إذا كان فارغاً نستخدم الافتراضي؛ أي نموذج يختاره المستخدم يبقى كما هو
            if (saved.isNullOrBlank()) return DEFAULT_LLM
            return saved
        }
        set(v) { p.edit().putString("llm", v).apply() }

    var smart: Boolean
        get() = p.getBoolean("smart", true)
        set(v) { p.edit().putBoolean("smart", v).apply() }

    /** تمريرة مراجعة ثانية للياباني→العربي (أدق لكنها تضاعف استهلاك الحد المجاني). */
    var review: Boolean
        get() = p.getBoolean("review", false)
        set(v) { p.edit().putBoolean("review", v).apply() }

    var autoPause: Boolean
        get() = p.getBoolean("autoPause", true)
        set(v) { p.edit().putBoolean("autoPause", v).apply() }

    var bg: Boolean
        get() = p.getBoolean("bg", true)
        set(v) { p.edit().putBoolean("bg", v).apply() }

    var fontSize: Float
        get() = p.getFloat("font", 20f)
        set(v) { p.edit().putFloat("font", v).apply() }

    var fontStyle: String
        get() = p.getString("fontStyle", "normal") ?: "normal"
        set(v) { p.edit().putString("fontStyle", v).apply() }

    var shift: Float
        get() = p.getFloat("shift", 0f)
        set(v) { p.edit().putFloat("shift", v).apply() }

    var lang: String
        get() = p.getString("lang", "auto") ?: "auto"
        set(v) { p.edit().putString("lang", v).apply() }

    var targetLang: String
        get() = p.getString("targetLang", "ar") ?: "ar"
        set(v) { p.edit().putString("targetLang", if (v == "en") "en" else "ar").apply() }

    companion object {
        const val DEFAULT_URL = "https://api.groq.com/openai/v1"
        const val DEFAULT_WHISPER = "whisper-large-v3-turbo"
        const val DEFAULT_LLM = "llama-3.3-70b-versatile"
    }
}
