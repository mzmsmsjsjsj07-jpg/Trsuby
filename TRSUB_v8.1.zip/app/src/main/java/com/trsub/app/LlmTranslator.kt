package com.trsub.app

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

object LlmTranslator {

    private fun targetName(targetLang: String) =
        if (targetLang == "en") "English (natural spoken dialogue subtitles)"
        else "Arabic (Modern Standard Arabic; natural dialogue subtitles)"

    /** تعليمات النظام تتبع اللغة الهدف (إنجليزي أو عربي). */
    private fun systemPrompt(targetLang: String): String {
        val targetRule = if (targetLang == "en")
            "- Write natural, idiomatic English that sounds like spoken dialogue. Never output Arabic or any language other than English."
        else
            "- Use Modern Standard Arabic that sounds natural in spoken dialogue. Never output English unless it is a proper name."
        return """
You are a professional subtitle translator for anime, films and series.
Translate every line from the stated source language into the stated target language. Produce fluent, natural subtitles, not a literal word-for-word translation.

CRITICAL RULES FOR JAPANESE DIALOGUE:
- Japanese frequently omits the subject, object and pronouns. Infer it from the context only when the evidence supports it.
- Keep references to characters, relationships, number, negation, and tense consistent.
- Treat previous bilingual context as continuity evidence, not as text to translate again.

GENERAL RULES:
$targetRule
- Keep exactly one output string per input line in the same order. Return JSON only: {"translations": ["..."]}. No markdown or commentary.
""".trimIndent()
    }

    private fun reviewPrompt(): String = """
You are a strict senior subtitle editor specializing in Japanese-to-Arabic dialogue.
Review and improve the draft. Verify pronoun inference, natural dialogue phrasing, and tense.
Keep exactly one output string per input line in the same order.
Return valid JSON only in the form {"translations": ["..."]}.
""".trimIndent()

    suspend fun translate(
        http: OkHttpClient, baseUrl: String, model: String, key: String,
        sourceLang: String, targetLang: String, lines: List<String>, context: List<String>,
        review: Boolean = false
    ): List<String> {
        val user = JSONObject()
            .put("source_language", sourceLang)
            .put("target_language", targetName(targetLang))
            .put("previous_dialogue_context_source_and_target", JSONArray(context))
            .put("lines_to_translate", JSONArray(lines))

        val first = requestTranslations(
            http, baseUrl, model, key, systemPrompt(targetLang), user, lines.size,
            attempts = 3, temperature = 0.15
        )

        if (!review || !isJapanese(sourceLang) || targetLang != "ar" || lines.isEmpty()) return first
        return try {
            val reviewUser = JSONObject()
                .put("source_language", sourceLang)
                .put("target_language", targetName("ar"))
                .put("previous_dialogue_context_source_and_target", JSONArray(context))
                .put("original_lines", JSONArray(lines))
                .put("draft_translations", JSONArray(first))
            val reviewed = requestTranslations(
                http, baseUrl, model, key, reviewPrompt(), reviewUser,
                lines.size, attempts = 1, temperature = 0.05
            )
            reviewed.mapIndexed { index, line -> line.ifBlank { first[index] } }
        } catch (e: CancellationException) {
            throw e
        } catch (e: FatalApiError) {
            throw e
        } catch (_: Exception) {
            first // فشلت المراجعة: نكتفي بالمسودة
        }
    }

    private fun isJapanese(sourceLang: String): Boolean {
        val s = sourceLang.lowercase(Locale.ROOT).trim()
        return s == "ja" || s.startsWith("ja-") || s == "japanese" || s == "اليابانية"
    }

    private suspend fun requestTranslations(
        http: OkHttpClient, baseUrl: String, model: String, key: String,
        system: String, user: JSONObject, expected: Int, attempts: Int, temperature: Double
    ): List<String> {
        val bodyStr = JSONObject()
            .put("model", model)
            .put("temperature", temperature)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user.toString()))
            ).toString()

        var lastError: Exception? = null
        for (attempt in 1..attempts) {
            val req = Request.Builder()
                .url(baseUrl.trimEnd('/') + "/chat/completions")
                .header("Authorization", "Bearer $key")
                .post(bodyStr.toRequestBody("application/json; charset=utf-8".toMediaType()))
                .build()

            val resp = http.newCall(req).awaitResponse()
            val code = resp.code
            val wait = Api.retryDelayMs(resp, attempt)
            val text = resp.body?.string() ?: ""
            resp.close()

            when {
                code in 200..299 -> {
                    try {
                        return parse(text, expected)
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        // رد غير صالح أو عدد أسطر غير مطابق: نعيد المحاولة بدل إزاحة الترجمة
                        lastError = e
                        if (attempt < attempts) delay(1000)
                    }
                }
                code == 401 || code == 403 -> throw FatalApiError("مفتاح API غير صحيح أو لا يملك صلاحية")
                code == 404 -> throw FatalApiError("اسم النموذج غير مدعوم على هذا المزود: $model")
                code == 429 || code in 500..599 -> {
                    lastError = Exception("الخدمة مشغولة حالياً، أعد المحاولة بعد قليل")
                    if (attempt < attempts) delay(wait)
                }
                else -> throw Exception("خطأ ($code): ${text.take(120)}")
            }
        }
        throw lastError ?: Exception("تعذّر الاتصال")
    }

    private fun parse(json: String, expected: Int): List<String> {
        val raw = JSONObject(json)
            .getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content", "").trim()
        if (raw.isEmpty()) throw Exception("رد فارغ من النموذج")

        // استخراج كتلة JSON بأمان حتى لو تضمنت وسوماً أو نص تفكير
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) throw Exception("تعذر العثور على صيغة JSON في رد النموذج")

        val arr = JSONObject(raw.substring(start, end + 1)).getJSONArray("translations")
        // صارم: أي اختلاف في العدد يعني احتمال إزاحة الأسطر، فنرفضه
        if (arr.length() != expected) throw Exception("عدد الأسطر المترجمة غير مطابق (${arr.length()} بدل $expected)")
        val out = ArrayList<String>(expected)
        for (i in 0 until arr.length()) out.add(arr.optString(i, "").trim())
        return out
    }
}
